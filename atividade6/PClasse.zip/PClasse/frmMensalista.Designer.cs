﻿namespace PClasse2
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblMatricula = new Label();
            txtMatricula = new TextBox();
            txtNome = new TextBox();
            lblNome = new Label();
            txtSalarioMensal = new TextBox();
            lblSalarioMensal = new Label();
            txtDataEntradaEmpresa = new TextBox();
            lblDataEntradaEmpresa = new Label();
            btnInstanciarMensalista = new Button();
            btnInstanciarMensalistaParametros = new Button();
            SuspendLayout();
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblMatricula.Location = new Point(80, 40);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(75, 20);
            lblMatricula.TabIndex = 0;
            lblMatricula.Text = "Matricula";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(278, 37);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(100, 23);
            txtMatricula.TabIndex = 1;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(278, 89);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(211, 23);
            txtNome.TabIndex = 3;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblNome.Location = new Point(80, 92);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(52, 20);
            lblNome.TabIndex = 2;
            lblNome.Text = "Nome";
            // 
            // txtSalarioMensal
            // 
            txtSalarioMensal.Location = new Point(278, 132);
            txtSalarioMensal.Name = "txtSalarioMensal";
            txtSalarioMensal.Size = new Size(77, 23);
            txtSalarioMensal.TabIndex = 5;
            // 
            // lblSalarioMensal
            // 
            lblSalarioMensal.AutoSize = true;
            lblSalarioMensal.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblSalarioMensal.Location = new Point(80, 135);
            lblSalarioMensal.Name = "lblSalarioMensal";
            lblSalarioMensal.Size = new Size(110, 20);
            lblSalarioMensal.TabIndex = 4;
            lblSalarioMensal.Text = "Salário Mensal";
            // 
            // txtDataEntradaEmpresa
            // 
            txtDataEntradaEmpresa.Location = new Point(278, 177);
            txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            txtDataEntradaEmpresa.Size = new Size(100, 23);
            txtDataEntradaEmpresa.TabIndex = 7;
            // 
            // lblDataEntradaEmpresa
            // 
            lblDataEntradaEmpresa.AutoSize = true;
            lblDataEntradaEmpresa.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblDataEntradaEmpresa.Location = new Point(80, 177);
            lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            lblDataEntradaEmpresa.Size = new Size(185, 20);
            lblDataEntradaEmpresa.TabIndex = 6;
            lblDataEntradaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // btnInstanciarMensalista
            // 
            btnInstanciarMensalista.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInstanciarMensalista.Location = new Point(80, 242);
            btnInstanciarMensalista.Name = "btnInstanciarMensalista";
            btnInstanciarMensalista.Size = new Size(157, 55);
            btnInstanciarMensalista.TabIndex = 8;
            btnInstanciarMensalista.Text = "Instanciar Mensalista";
            btnInstanciarMensalista.UseVisualStyleBackColor = true;
            btnInstanciarMensalista.Click += btnInstanciarMensalista_Click;
            // 
            // btnInstanciarMensalistaParametros
            // 
            btnInstanciarMensalistaParametros.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInstanciarMensalistaParametros.Location = new Point(278, 242);
            btnInstanciarMensalistaParametros.Name = "btnInstanciarMensalistaParametros";
            btnInstanciarMensalistaParametros.Size = new Size(213, 55);
            btnInstanciarMensalistaParametros.TabIndex = 9;
            btnInstanciarMensalistaParametros.Text = "Instanciar Mensalista passando parâmetros";
            btnInstanciarMensalistaParametros.UseVisualStyleBackColor = true;
            btnInstanciarMensalistaParametros.Click += btnInstanciarMensalistaParametros_Click;
            // 
            // frmMensalista
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(939, 515);
            Controls.Add(btnInstanciarMensalistaParametros);
            Controls.Add(btnInstanciarMensalista);
            Controls.Add(txtDataEntradaEmpresa);
            Controls.Add(lblDataEntradaEmpresa);
            Controls.Add(txtSalarioMensal);
            Controls.Add(lblSalarioMensal);
            Controls.Add(txtNome);
            Controls.Add(lblNome);
            Controls.Add(txtMatricula);
            Controls.Add(lblMatricula);
            Name = "frmMensalista";
            Text = "frmMensalista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblMatricula;
        private TextBox txtMatricula;
        private TextBox txtNome;
        private Label lblNome;
        private TextBox txtSalarioMensal;
        private Label lblSalarioMensal;
        private TextBox txtDataEntradaEmpresa;
        private Label lblDataEntradaEmpresa;
        private Button btnInstanciarMensalista;
        private Button btnInstanciarMensalistaParametros;
    }
}