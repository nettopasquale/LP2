﻿using PClasse;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasse2
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciarHorista_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalarioHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumeroHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFaltas.Text);

            MessageBox.Show($" Nome {objHorista.NomeEmpregado} \n " +
                $"Matrícula {objHorista.Matricula} \n" +
                $" Tempo de trabalho {objHorista.TempoTrabalho()} \n" +
                $" Salário: {objHorista.salarioBruto().ToString("N2")}");
        }

        private void txtDataEntradaEmpresa_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
