﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasse
{
    internal class Mensalista : Empregado
    {
        public double SalarioMensal { get; set; }

        //sobreescrevendo o método

        public override double salarioBruto()
        {
            return SalarioMensal;
        }

        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("aqui é mensalista");
        }

        public Mensalista (int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }

        // static será o mesmo para todas as filhas instâncias dessa classe
        public static String Empresa = "Toyota";

        public const String Filial = "Filial Sorocaba";
    }
}
