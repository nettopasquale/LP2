﻿namespace PClasse2
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnInstanciarHorista = new Button();
            txtDataEntradaEmpresa = new TextBox();
            lblDataEntradaEmpresa = new Label();
            txtSalarioHora = new TextBox();
            lblSalarioHora = new Label();
            txtNome = new TextBox();
            lblNome = new Label();
            txtMatricula = new TextBox();
            lblMatricula = new Label();
            txtNumeroHoras = new TextBox();
            lblNumeroHora = new Label();
            txtFaltas = new TextBox();
            lblFaltas = new Label();
            SuspendLayout();
            // 
            // btnInstanciarHorista
            // 
            btnInstanciarHorista.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInstanciarHorista.Location = new Point(222, 341);
            btnInstanciarHorista.Name = "btnInstanciarHorista";
            btnInstanciarHorista.Size = new Size(185, 55);
            btnInstanciarHorista.TabIndex = 12;
            btnInstanciarHorista.Text = "Instanciar Horista";
            btnInstanciarHorista.UseVisualStyleBackColor = true;
            btnInstanciarHorista.Click += btnInstanciarHorista_Click;
            // 
            // txtDataEntradaEmpresa
            // 
            txtDataEntradaEmpresa.Location = new Point(279, 233);
            txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            txtDataEntradaEmpresa.Size = new Size(100, 23);
            txtDataEntradaEmpresa.TabIndex = 9;
            txtDataEntradaEmpresa.TextChanged += txtDataEntradaEmpresa_TextChanged;
            // 
            // lblDataEntradaEmpresa
            // 
            lblDataEntradaEmpresa.AutoSize = true;
            lblDataEntradaEmpresa.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblDataEntradaEmpresa.Location = new Point(66, 236);
            lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            lblDataEntradaEmpresa.Size = new Size(185, 20);
            lblDataEntradaEmpresa.TabIndex = 8;
            lblDataEntradaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // txtSalarioHora
            // 
            txtSalarioHora.Location = new Point(279, 144);
            txtSalarioHora.Name = "txtSalarioHora";
            txtSalarioHora.Size = new Size(77, 23);
            txtSalarioHora.TabIndex = 5;
            // 
            // lblSalarioHora
            // 
            lblSalarioHora.AutoSize = true;
            lblSalarioHora.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblSalarioHora.Location = new Point(66, 147);
            lblSalarioHora.Name = "lblSalarioHora";
            lblSalarioHora.Size = new Size(122, 20);
            lblSalarioHora.TabIndex = 4;
            lblSalarioHora.Text = "Salário por Hora";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(279, 101);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(211, 23);
            txtNome.TabIndex = 3;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblNome.Location = new Point(66, 104);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(52, 20);
            lblNome.TabIndex = 2;
            lblNome.Text = "Nome";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(279, 58);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(100, 23);
            txtMatricula.TabIndex = 1;
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblMatricula.Location = new Point(66, 61);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(75, 20);
            lblMatricula.TabIndex = 0;
            lblMatricula.Text = "Matricula";
            // 
            // txtNumeroHoras
            // 
            txtNumeroHoras.Location = new Point(279, 191);
            txtNumeroHoras.Name = "txtNumeroHoras";
            txtNumeroHoras.Size = new Size(77, 23);
            txtNumeroHoras.TabIndex = 7;
            // 
            // lblNumeroHora
            // 
            lblNumeroHora.AutoSize = true;
            lblNumeroHora.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblNumeroHora.Location = new Point(66, 194);
            lblNumeroHora.Name = "lblNumeroHora";
            lblNumeroHora.Size = new Size(133, 20);
            lblNumeroHora.TabIndex = 6;
            lblNumeroHora.Text = "Número de Horas";
            // 
            // txtFaltas
            // 
            txtFaltas.Location = new Point(279, 280);
            txtFaltas.Name = "txtFaltas";
            txtFaltas.Size = new Size(77, 23);
            txtFaltas.TabIndex = 11;
            // 
            // lblFaltas
            // 
            lblFaltas.AutoSize = true;
            lblFaltas.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lblFaltas.Location = new Point(66, 283);
            lblFaltas.Name = "lblFaltas";
            lblFaltas.Size = new Size(133, 20);
            lblFaltas.TabIndex = 10;
            lblFaltas.Text = "Número de Faltas";
            // 
            // frmHorista
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtFaltas);
            Controls.Add(lblFaltas);
            Controls.Add(txtNumeroHoras);
            Controls.Add(lblNumeroHora);
            Controls.Add(btnInstanciarHorista);
            Controls.Add(txtDataEntradaEmpresa);
            Controls.Add(lblDataEntradaEmpresa);
            Controls.Add(txtSalarioHora);
            Controls.Add(lblSalarioHora);
            Controls.Add(txtNome);
            Controls.Add(lblNome);
            Controls.Add(txtMatricula);
            Controls.Add(lblMatricula);
            Name = "frmHorista";
            Text = "frmHorista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnInstanciarHorista;
        private TextBox txtDataEntradaEmpresa;
        private Label lblDataEntradaEmpresa;
        private TextBox txtSalarioHora;
        private Label lblSalarioHora;
        private TextBox txtNome;
        private Label lblNome;
        private TextBox txtMatricula;
        private Label lblMatricula;
        private TextBox txtNumeroHoras;
        private Label lblNumeroHora;
        private TextBox txtFaltas;
        private Label lblFaltas;
    }
}