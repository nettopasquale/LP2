namespace Pcalc
{
    public partial class Form1 : Form
    {
        double vlrNumb1, vlrNumb2, result;

        public Form1()
        {
            InitializeComponent();
        }

        private void lblnum1_Click(object sender, EventArgs e)
        {

        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = String.Empty;
            txtNum2.Text = String.Empty;
            txtResultado.Text = String.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtNum1.Text, out vlrNumb1))
            {
                MessageBox.Show("Valor incorreto!");
                txtNum1.Focus();
            }

        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtNum2.Text, out vlrNumb2))
            {
                MessageBox.Show("Valor incorreto!");
                txtNum1.Focus();
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
                result = vlrNumb1 + vlrNumb2;
                txtResultado.Text = result.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
                result = vlrNumb1 - vlrNumb2;
                txtResultado.Text = result.ToString();
            
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
                result = vlrNumb1 * vlrNumb2;
                txtResultado.Text = result.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {

            if (vlrNumb2 == 0){
                MessageBox.Show("Divis�o por 0 imposs�vel. Tente outro n�mero!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();

            }else{
                result = vlrNumb1 / vlrNumb2;
                txtResultado.Text = result.ToString();
            }
        }
    }
}
