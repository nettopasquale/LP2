﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNum1 = new Label();
            txtNum1 = new TextBox();
            btnLimpar = new Button();
            btnSair = new Button();
            txtNum2 = new TextBox();
            lblNum2 = new Label();
            txtResultado = new TextBox();
            lblResultado = new Label();
            btnAdd = new Button();
            btnSub = new Button();
            btnMulti = new Button();
            btnDiv = new Button();
            SuspendLayout();
            // 
            // lblNum1
            // 
            lblNum1.AutoSize = true;
            lblNum1.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold);
            lblNum1.Location = new Point(43, 64);
            lblNum1.Name = "lblNum1";
            lblNum1.Size = new Size(70, 17);
            lblNum1.TabIndex = 0;
            lblNum1.Text = "Numero 1";
            lblNum1.Click += lblnum1_Click;
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(129, 63);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(141, 23);
            txtNum1.TabIndex = 1;
            txtNum1.TextChanged += txtNum1_TextChanged;
            txtNum1.Validated += txtNum1_Validated;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(289, 62);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(89, 37);
            btnLimpar.TabIndex = 2;
            btnLimpar.Text = "limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(289, 124);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(89, 37);
            btnSair.TabIndex = 5;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(129, 125);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(141, 23);
            txtNum2.TabIndex = 4;
            txtNum2.Validated += txtNum2_Validated;
            // 
            // lblNum2
            // 
            lblNum2.AutoSize = true;
            lblNum2.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold);
            lblNum2.Location = new Point(43, 125);
            lblNum2.Name = "lblNum2";
            lblNum2.Size = new Size(72, 17);
            lblNum2.TabIndex = 3;
            lblNum2.Text = "Numero 2";
            // 
            // txtResultado
            // 
            txtResultado.Enabled = false;
            txtResultado.Location = new Point(129, 193);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(141, 23);
            txtResultado.TabIndex = 7;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold);
            lblResultado.Location = new Point(43, 193);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(70, 17);
            lblResultado.TabIndex = 6;
            lblResultado.Text = "Resultado";
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.Location = new Point(43, 261);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(83, 44);
            btnAdd.TabIndex = 8;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSub
            // 
            btnSub.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSub.Location = new Point(155, 261);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(83, 44);
            btnSub.TabIndex = 9;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += btnSub_Click;
            // 
            // btnMulti
            // 
            btnMulti.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMulti.Location = new Point(270, 261);
            btnMulti.Name = "btnMulti";
            btnMulti.Size = new Size(83, 44);
            btnMulti.TabIndex = 10;
            btnMulti.Text = "*";
            btnMulti.UseVisualStyleBackColor = true;
            btnMulti.Click += btnMulti_Click;
            // 
            // btnDiv
            // 
            btnDiv.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDiv.Location = new Point(389, 261);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(83, 44);
            btnDiv.TabIndex = 11;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += btnDiv_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnDiv);
            Controls.Add(btnMulti);
            Controls.Add(btnSub);
            Controls.Add(btnAdd);
            Controls.Add(txtResultado);
            Controls.Add(lblResultado);
            Controls.Add(btnSair);
            Controls.Add(txtNum2);
            Controls.Add(lblNum2);
            Controls.Add(btnLimpar);
            Controls.Add(txtNum1);
            Controls.Add(lblNum1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNum1;
        private TextBox txtNum1;
        private Button btnLimpar;
        private Button btnSair;
        private TextBox txtNum2;
        private Label lblNum2;
        private TextBox txtResultado;
        private Label lblResultado;
        private Button btnAdd;
        private Button btnSub;
        private Button btnMulti;
        private Button btnDiv;
    }
}
