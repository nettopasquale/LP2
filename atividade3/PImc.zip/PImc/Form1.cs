namespace PImc
{
    public partial class Form1 : Form
    {

        double pesoAtual, altura, resultado, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Text = String.Empty;
            mskbxAltura.Text = String.Empty;
            mskbxIMC.Text = String.Empty;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            if (altura == 0)
                MessageBox.Show("Altura incorreta! Informe valor maior que 0.");
            else if (pesoAtual ==0)
                MessageBox.Show("Peso incorreto! Informe valor maior que 0.");
            else
            {
                resultado = pesoAtual / Math.Pow(altura, 2);
                imc = Math.Round(resultado, 1);
                mskbxIMC.Text = imc.ToString();
            }

                if (imc < 18.5)
                    MessageBox.Show("Classifica��o IMC: Magreza");
                else if(imc >= 18.5 && imc < 25)
                    MessageBox.Show("Classifica��o IMC: Normal");
                else if(imc >= 25 && imc < 30)
                    MessageBox.Show("Classifica��o IMC: Sobrepeso");
                else if(imc >= 30 && imc < 40)
                    MessageBox.Show("Classifica��o IMC: Obesidade");
                else
                    MessageBox.Show("Classifica��o IMC: Obesidade Grave");
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out pesoAtual))
            {
                MessageBox.Show("Peso Incorreto! Favor corrigir valor informado.");
                mskbxPeso.Focus();

            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura Incorreta! Favor corrigir valor informado.");
                mskbxAltura.Focus();

            }
        }
    }
}
