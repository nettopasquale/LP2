﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPeso = new Label();
            btnCalcular = new Button();
            mskbxPeso = new MaskedTextBox();
            mskbxAltura = new MaskedTextBox();
            lblAltura = new Label();
            mskbxIMC = new MaskedTextBox();
            lblIMC = new Label();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPeso.Location = new Point(50, 74);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(105, 25);
            lblPeso.TabIndex = 0;
            lblPeso.Text = "Peso Atual";
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalcular.Location = new Point(50, 255);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(105, 45);
            btnCalcular.TabIndex = 1;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // mskbxPeso
            // 
            mskbxPeso.Location = new Point(172, 74);
            mskbxPeso.Mask = "000.00";
            mskbxPeso.Name = "mskbxPeso";
            mskbxPeso.Size = new Size(112, 23);
            mskbxPeso.TabIndex = 2;
            mskbxPeso.Validated += mskbxPeso_Validated;
            // 
            // mskbxAltura
            // 
            mskbxAltura.Location = new Point(172, 134);
            mskbxAltura.Mask = "0.00";
            mskbxAltura.Name = "mskbxAltura";
            mskbxAltura.Size = new Size(112, 23);
            mskbxAltura.TabIndex = 4;
            mskbxAltura.Validated += mskbxAltura_Validated;
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAltura.Location = new Point(50, 134);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(67, 25);
            lblAltura.TabIndex = 3;
            lblAltura.Text = "Altura";
            lblAltura.Click += label1_Click;
            // 
            // mskbxIMC
            // 
            mskbxIMC.Enabled = false;
            mskbxIMC.Location = new Point(172, 191);
            mskbxIMC.Name = "mskbxIMC";
            mskbxIMC.Size = new Size(112, 23);
            mskbxIMC.TabIndex = 6;
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblIMC.Location = new Point(50, 191);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(48, 25);
            lblIMC.TabIndex = 5;
            lblIMC.Text = "IMC";
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLimpar.Location = new Point(172, 255);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(100, 45);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSair.Location = new Point(294, 255);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(91, 45);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(mskbxIMC);
            Controls.Add(lblIMC);
            Controls.Add(mskbxAltura);
            Controls.Add(lblAltura);
            Controls.Add(mskbxPeso);
            Controls.Add(btnCalcular);
            Controls.Add(lblPeso);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPeso;
        private Button btnCalcular;
        private MaskedTextBox mskbxPeso;
        private MaskedTextBox mskbxAltura;
        private Label lblAltura;
        private MaskedTextBox mskbxIMC;
        private Label lblIMC;
        private Button btnLimpar;
        private Button btnSair;
    }
}
