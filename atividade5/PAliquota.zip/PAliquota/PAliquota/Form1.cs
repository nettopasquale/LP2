namespace PAliquota
{
    public partial class Form1 : Form
    {
        double salarioBruto, descontoINSS, descontoIRPF, salarioFamilia, numeroFilhos, salarioLiquido;
        public Form1()
        {
            InitializeComponent();
        }

        private void lblFamilia_Click(object sender, EventArgs e)
        {

        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar))
            {
                MessageBox.Show("Caracter inv�lido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text.Length > 50)
            {
                MessageBox.Show("Por favor dig�te um nome v�lido!");
                txtNome.Text = String.Empty;
                txtNome.Focus();
            }
        }

        private void mksbSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mksbSalario.Text, out salarioBruto))
            {
                MessageBox.Show("Sal�rio Inv�lido! Por favor digite novamente.");
                mksbSalario.Text = String.Empty;
                mksbSalario.Focus();
            }
        }
        private void numUDFilhos_Validated(object sender, EventArgs e)
        {
            numeroFilhos = Decimal.ToDouble(numUDFilhos.Value);

        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            if (salarioBruto == 0)
            {
                MessageBox.Show("Digite um sal�rio acima de 0!");
            }
            else if (txtNome.Text == "")
            {
                MessageBox.Show("Campo vazio. Por favor digite um nome!");
            }

            if (salarioBruto > 2801.56)
            {
                txtAliquotaINSS.Text = "teto";
                descontoINSS = 308.17;
                txtDescontoINSS.Text = descontoINSS.ToString();

            }
            else if (salarioBruto >= 1400.78 && salarioBruto <= 2801.56)
            {
                txtAliquotaINSS.Text = "11%";
                descontoINSS = salarioBruto * 0.11;
                txtDescontoINSS.Text = descontoINSS.ToString("N2");

            }
            else if (salarioBruto >= 1050.01 && salarioBruto <= 1400.777)
            {
                txtAliquotaINSS.Text = "9.00%";
                descontoINSS = salarioBruto * 0.09;
                txtDescontoINSS.Text = descontoINSS.ToString("N2");

            }
            else if (salarioBruto >= 800.48 && salarioBruto <= 1050)
            {
                txtAliquotaINSS.Text = "8.65%";
                descontoINSS = salarioBruto * 0.0865;
                txtDescontoINSS.Text = descontoINSS.ToString("N2");
            }
            else
            {
                txtAliquotaINSS.Text = "7.65%";
                descontoINSS = salarioBruto * 0.0765;
                txtDescontoINSS.Text = descontoINSS.ToString("N2");
            }

            if (salarioBruto > 2512.08)
            {
                txtAliquotaIRPF.Text = "27.5%";
                descontoIRPF = salarioBruto * 0.275;
                txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
            }
            else if (salarioBruto >= 1257.13 && salarioBruto <= 2512.08)
            {
                txtAliquotaIRPF.Text = "15.00%";
                descontoIRPF = salarioBruto * 0.15;
                txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
            }
            else
            {
                txtAliquotaIRPF.Text = "isento";
                descontoIRPF = 0;
                txtDescontoIRPF.Text = descontoIRPF.ToString();
            }

            if (salarioBruto > 654.61)
            {
                salarioFamilia = 0;
                txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
            }
            else if (salarioFamilia >= 435.533 && salarioFamilia <= 654.51)
            {
                salarioFamilia = numeroFilhos * 15.74;
                txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
            }
            else
            {
                salarioFamilia = numeroFilhos * 22.33;
                txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
            }

            salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;

            txtSalarioLiquido.Text = salarioLiquido.ToString("N2");

        }
        private void btnLimpa_Click(object sender, EventArgs e)
        {
            txtNome.Text = String.Empty;
            mksbSalario.Text = String.Empty;
            numUDFilhos.Text = String.Empty;
            txtAliquotaINSS.Text = String.Empty;
            txtAliquotaIRPF.Text = String.Empty;
            txtDescontoINSS.Text = String.Empty;
            txtDescontoIRPF.Text = String.Empty;
            txtSalarioFamilia.Text= String.Empty;
            txtSalarioLiquido.Text= String.Empty;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
