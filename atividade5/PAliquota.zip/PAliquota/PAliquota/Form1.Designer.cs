﻿namespace PAliquota
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblFuncionario = new Label();
            lblSalarioBruto = new Label();
            lblFilhos = new Label();
            lblINSS = new Label();
            lblFamilia = new Label();
            lblIRPF = new Label();
            lblLiquido = new Label();
            lblDescontoINSS = new Label();
            lblDescontoIRPF = new Label();
            txtAliquotaINSS = new TextBox();
            txtAliquotaIRPF = new TextBox();
            txtSalarioFamilia = new TextBox();
            txtSalarioLiquido = new TextBox();
            txtDescontoINSS = new TextBox();
            txtDescontoIRPF = new TextBox();
            mksbSalario = new MaskedTextBox();
            btnDesconto = new Button();
            txtNome = new TextBox();
            numUDFilhos = new NumericUpDown();
            btnLimpa = new Button();
            btnClose = new Button();
            ((System.ComponentModel.ISupportInitialize)numUDFilhos).BeginInit();
            SuspendLayout();
            // 
            // lblFuncionario
            // 
            lblFuncionario.AutoSize = true;
            lblFuncionario.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblFuncionario.Location = new Point(69, 77);
            lblFuncionario.Margin = new Padding(4, 0, 4, 0);
            lblFuncionario.Name = "lblFuncionario";
            lblFuncionario.Size = new Size(201, 30);
            lblFuncionario.TabIndex = 0;
            lblFuncionario.Text = "Nome Funcionário";
            // 
            // lblSalarioBruto
            // 
            lblSalarioBruto.AutoSize = true;
            lblSalarioBruto.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblSalarioBruto.Location = new Point(69, 209);
            lblSalarioBruto.Margin = new Padding(4, 0, 4, 0);
            lblSalarioBruto.Name = "lblSalarioBruto";
            lblSalarioBruto.Size = new Size(147, 30);
            lblSalarioBruto.TabIndex = 2;
            lblSalarioBruto.Text = "Salário Bruto";
            // 
            // lblFilhos
            // 
            lblFilhos.AutoSize = true;
            lblFilhos.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblFilhos.Location = new Point(69, 323);
            lblFilhos.Margin = new Padding(4, 0, 4, 0);
            lblFilhos.Name = "lblFilhos";
            lblFilhos.Size = new Size(194, 30);
            lblFilhos.TabIndex = 3;
            lblFilhos.Text = "Número de Filhos";
            // 
            // lblINSS
            // 
            lblINSS.AutoSize = true;
            lblINSS.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblINSS.Location = new Point(75, 602);
            lblINSS.Margin = new Padding(4, 0, 4, 0);
            lblINSS.Name = "lblINSS";
            lblINSS.Size = new Size(155, 30);
            lblINSS.TabIndex = 4;
            lblINSS.Text = "Alíquota INSS";
            // 
            // lblFamilia
            // 
            lblFamilia.AutoSize = true;
            lblFamilia.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblFamilia.Location = new Point(75, 780);
            lblFamilia.Margin = new Padding(4, 0, 4, 0);
            lblFamilia.Name = "lblFamilia";
            lblFamilia.Size = new Size(161, 30);
            lblFamilia.TabIndex = 5;
            lblFamilia.Text = "Salário Família";
            lblFamilia.Click += lblFamilia_Click;
            // 
            // lblIRPF
            // 
            lblIRPF.AutoSize = true;
            lblIRPF.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblIRPF.Location = new Point(75, 689);
            lblIRPF.Margin = new Padding(4, 0, 4, 0);
            lblIRPF.Name = "lblIRPF";
            lblIRPF.Size = new Size(153, 30);
            lblIRPF.TabIndex = 6;
            lblIRPF.Text = "Alíquota IRPF";
            // 
            // lblLiquido
            // 
            lblLiquido.AutoSize = true;
            lblLiquido.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblLiquido.Location = new Point(75, 871);
            lblLiquido.Margin = new Padding(4, 0, 4, 0);
            lblLiquido.Name = "lblLiquido";
            lblLiquido.Size = new Size(166, 30);
            lblLiquido.TabIndex = 7;
            lblLiquido.Text = "Salário Líquido";
            // 
            // lblDescontoINSS
            // 
            lblDescontoINSS.AutoSize = true;
            lblDescontoINSS.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblDescontoINSS.Location = new Point(945, 602);
            lblDescontoINSS.Margin = new Padding(4, 0, 4, 0);
            lblDescontoINSS.Name = "lblDescontoINSS";
            lblDescontoINSS.Size = new Size(164, 30);
            lblDescontoINSS.TabIndex = 8;
            lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRPF
            // 
            lblDescontoIRPF.AutoSize = true;
            lblDescontoIRPF.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblDescontoIRPF.Location = new Point(945, 689);
            lblDescontoIRPF.Margin = new Padding(4, 0, 4, 0);
            lblDescontoIRPF.Name = "lblDescontoIRPF";
            lblDescontoIRPF.Size = new Size(162, 30);
            lblDescontoIRPF.TabIndex = 9;
            lblDescontoIRPF.Text = "Desconto IRPF";
            // 
            // txtAliquotaINSS
            // 
            txtAliquotaINSS.Enabled = false;
            txtAliquotaINSS.Location = new Point(292, 608);
            txtAliquotaINSS.Margin = new Padding(4);
            txtAliquotaINSS.Name = "txtAliquotaINSS";
            txtAliquotaINSS.Size = new Size(391, 37);
            txtAliquotaINSS.TabIndex = 10;
            // 
            // txtAliquotaIRPF
            // 
            txtAliquotaIRPF.Enabled = false;
            txtAliquotaIRPF.Location = new Point(292, 695);
            txtAliquotaIRPF.Margin = new Padding(4);
            txtAliquotaIRPF.Name = "txtAliquotaIRPF";
            txtAliquotaIRPF.Size = new Size(391, 37);
            txtAliquotaIRPF.TabIndex = 11;
            // 
            // txtSalarioFamilia
            // 
            txtSalarioFamilia.Enabled = false;
            txtSalarioFamilia.Location = new Point(292, 786);
            txtSalarioFamilia.Margin = new Padding(4);
            txtSalarioFamilia.Name = "txtSalarioFamilia";
            txtSalarioFamilia.Size = new Size(391, 37);
            txtSalarioFamilia.TabIndex = 12;
            // 
            // txtSalarioLiquido
            // 
            txtSalarioLiquido.Enabled = false;
            txtSalarioLiquido.Location = new Point(292, 877);
            txtSalarioLiquido.Margin = new Padding(4);
            txtSalarioLiquido.Name = "txtSalarioLiquido";
            txtSalarioLiquido.Size = new Size(391, 37);
            txtSalarioLiquido.TabIndex = 13;
            // 
            // txtDescontoINSS
            // 
            txtDescontoINSS.Enabled = false;
            txtDescontoINSS.Location = new Point(1179, 601);
            txtDescontoINSS.Margin = new Padding(4);
            txtDescontoINSS.Name = "txtDescontoINSS";
            txtDescontoINSS.Size = new Size(391, 37);
            txtDescontoINSS.TabIndex = 14;
            // 
            // txtDescontoIRPF
            // 
            txtDescontoIRPF.Enabled = false;
            txtDescontoIRPF.Location = new Point(1179, 688);
            txtDescontoIRPF.Margin = new Padding(4);
            txtDescontoIRPF.Name = "txtDescontoIRPF";
            txtDescontoIRPF.Size = new Size(391, 37);
            txtDescontoIRPF.TabIndex = 15;
            // 
            // mksbSalario
            // 
            mksbSalario.Location = new Point(338, 210);
            mksbSalario.Margin = new Padding(4);
            mksbSalario.Mask = "00000.00";
            mksbSalario.Name = "mksbSalario";
            mksbSalario.Size = new Size(339, 37);
            mksbSalario.TabIndex = 3;
            mksbSalario.ValidatingType = typeof(int);
            mksbSalario.Validated += mksbSalario_Validated;
            // 
            // btnDesconto
            // 
            btnDesconto.BackColor = SystemColors.ButtonHighlight;
            btnDesconto.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDesconto.Location = new Point(786, 402);
            btnDesconto.Margin = new Padding(4);
            btnDesconto.Name = "btnDesconto";
            btnDesconto.Size = new Size(278, 67);
            btnDesconto.TabIndex = 5;
            btnDesconto.Text = "Verifica Desconto";
            btnDesconto.UseVisualStyleBackColor = false;
            btnDesconto.Click += btnDesconto_Click;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(338, 70);
            txtNome.Margin = new Padding(4);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(1232, 37);
            txtNome.TabIndex = 1;
            txtNome.KeyPress += txtNome_KeyPress;
            txtNome.Validated += txtNome_Validated;
            // 
            // numUDFilhos
            // 
            numUDFilhos.Location = new Point(338, 316);
            numUDFilhos.Name = "numUDFilhos";
            numUDFilhos.Size = new Size(180, 37);
            numUDFilhos.TabIndex = 5;
            numUDFilhos.Validated += numUDFilhos_Validated;
            // 
            // btnLimpa
            // 
            btnLimpa.BackColor = SystemColors.ButtonHighlight;
            btnLimpa.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLimpa.Location = new Point(405, 1056);
            btnLimpa.Margin = new Padding(4);
            btnLimpa.Name = "btnLimpa";
            btnLimpa.Size = new Size(278, 67);
            btnLimpa.TabIndex = 17;
            btnLimpa.Text = "Limpar";
            btnLimpa.UseVisualStyleBackColor = false;
            btnLimpa.Click += btnLimpa_Click;
            // 
            // btnClose
            // 
            btnClose.BackColor = SystemColors.ButtonHighlight;
            btnClose.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClose.Location = new Point(1179, 1073);
            btnClose.Margin = new Padding(4);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(278, 67);
            btnClose.TabIndex = 18;
            btnClose.Text = "Fechar";
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += btnClose_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(2504, 1283);
            Controls.Add(btnClose);
            Controls.Add(btnLimpa);
            Controls.Add(numUDFilhos);
            Controls.Add(txtNome);
            Controls.Add(btnDesconto);
            Controls.Add(mksbSalario);
            Controls.Add(txtDescontoIRPF);
            Controls.Add(txtDescontoINSS);
            Controls.Add(txtSalarioLiquido);
            Controls.Add(txtSalarioFamilia);
            Controls.Add(txtAliquotaIRPF);
            Controls.Add(txtAliquotaINSS);
            Controls.Add(lblDescontoIRPF);
            Controls.Add(lblDescontoINSS);
            Controls.Add(lblLiquido);
            Controls.Add(lblIRPF);
            Controls.Add(lblFamilia);
            Controls.Add(lblINSS);
            Controls.Add(lblFilhos);
            Controls.Add(lblSalarioBruto);
            Controls.Add(lblFuncionario);
            Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)numUDFilhos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblFuncionario;
        private Label lblSalarioBruto;
        private Label lblFilhos;
        private Label lblINSS;
        private Label lblFamilia;
        private Label lblIRPF;
        private Label lblLiquido;
        private Label lblDescontoINSS;
        private Label lblDescontoIRPF;
        private TextBox txtAliquotaINSS;
        private TextBox txtAliquotaIRPF;
        private TextBox txtSalarioFamilia;
        private TextBox txtSalarioLiquido;
        private TextBox txtDescontoINSS;
        private TextBox txtDescontoIRPF;
        private MaskedTextBox mksbSalario;
        private Button btnDesconto;
        private TextBox txtNome;
        private NumericUpDown numUDFilhos;
        private Button btnLimpa;
        private Button btnClose;
    }
}
