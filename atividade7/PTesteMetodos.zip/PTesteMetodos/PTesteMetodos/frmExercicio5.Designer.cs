﻿namespace PTesteMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRandom = new Button();
            lblNumero2 = new Label();
            lblNumero1 = new Label();
            txtNumero2 = new TextBox();
            txtNumero1 = new TextBox();
            SuspendLayout();
            // 
            // btnRandom
            // 
            btnRandom.Location = new Point(453, 352);
            btnRandom.Margin = new Padding(4, 5, 4, 5);
            btnRandom.Name = "btnRandom";
            btnRandom.Size = new Size(191, 85);
            btnRandom.TabIndex = 18;
            btnRandom.Text = "Gerar Aleatório";
            btnRandom.UseVisualStyleBackColor = true;
            btnRandom.Click += btnRandom_Click;
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(759, 638);
            lblNumero2.Margin = new Padding(4, 0, 4, 0);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(92, 25);
            lblNumero2.TabIndex = 16;
            lblNumero2.Text = "Número 2";
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(61, 110);
            lblNumero1.Margin = new Padding(4, 0, 4, 0);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(92, 25);
            lblNumero1.TabIndex = 15;
            lblNumero1.Text = "Número 1";
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(859, 635);
            txtNumero2.Margin = new Padding(4, 5, 4, 5);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(224, 31);
            txtNumero2.TabIndex = 14;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(161, 107);
            txtNumero1.Margin = new Padding(4, 5, 4, 5);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(224, 31);
            txtNumero1.TabIndex = 13;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1143, 750);
            Controls.Add(btnRandom);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnRandom;
        private Label lblNumero2;
        private Label lblNumero1;
        private TextBox txtNumero2;
        private TextBox txtNumero1;
    }
}