﻿namespace PTesteMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            btnVerifica = new Button();
            btnInserir1_2 = new Button();
            btnInserir_no1 = new Button();
            SuspendLayout();
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(95, 27);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(158, 23);
            txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(160, 81);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(158, 23);
            txtPalavra2.TabIndex = 1;
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(30, 35);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(54, 15);
            lblPalavra1.TabIndex = 2;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(95, 89);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(54, 15);
            lblPalavra2.TabIndex = 3;
            lblPalavra2.Text = "Palavra 2";
            // 
            // btnVerifica
            // 
            btnVerifica.Location = new Point(224, 139);
            btnVerifica.Name = "btnVerifica";
            btnVerifica.Size = new Size(138, 51);
            btnVerifica.TabIndex = 4;
            btnVerifica.Text = "Verifica Iguais";
            btnVerifica.UseVisualStyleBackColor = true;
            btnVerifica.Click += btnVerifica_Click;
            // 
            // btnInserir1_2
            // 
            btnInserir1_2.Location = new Point(304, 223);
            btnInserir1_2.Name = "btnInserir1_2";
            btnInserir1_2.Size = new Size(134, 51);
            btnInserir1_2.TabIndex = 5;
            btnInserir1_2.Text = "Inserir 1º no meio do 2º";
            btnInserir1_2.UseVisualStyleBackColor = true;
            btnInserir1_2.Click += btnInserir1_2_Click;
            // 
            // btnInserir_no1
            // 
            btnInserir_no1.Location = new Point(384, 309);
            btnInserir_no1.Name = "btnInserir_no1";
            btnInserir_no1.Size = new Size(135, 51);
            btnInserir_no1.TabIndex = 6;
            btnInserir_no1.Text = "Inserir ** no meio 1º";
            btnInserir_no1.UseVisualStyleBackColor = true;
            btnInserir_no1.Click += btnInserir_no1_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInserir_no1);
            Controls.Add(btnInserir1_2);
            Controls.Add(btnVerifica);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Label lblPalavra1;
        private Label lblPalavra2;
        private Button btnVerifica;
        private Button btnInserir1_2;
        private Button btnInserir_no1;
    }
}