﻿namespace PTesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnInverse = new Button();
            btnRemove1do2 = new Button();
            lblPalavra2 = new Label();
            lblPalavra1 = new Label();
            txtPalavra2 = new TextBox();
            txtPalavra1 = new TextBox();
            SuspendLayout();
            // 
            // btnInverse
            // 
            btnInverse.Location = new Point(125, 263);
            btnInverse.Name = "btnInverse";
            btnInverse.Size = new Size(134, 51);
            btnInverse.TabIndex = 12;
            btnInverse.Text = "Inverter";
            btnInverse.UseVisualStyleBackColor = true;
            btnInverse.Click += btnInverse_Click;
            // 
            // btnRemove1do2
            // 
            btnRemove1do2.Location = new Point(257, 193);
            btnRemove1do2.Name = "btnRemove1do2";
            btnRemove1do2.Size = new Size(138, 51);
            btnRemove1do2.TabIndex = 11;
            btnRemove1do2.Text = "Remover Referências do 1º no 2º";
            btnRemove1do2.UseVisualStyleBackColor = true;
            btnRemove1do2.Click += btnRemove1do2_Click;
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(397, 145);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(54, 15);
            lblPalavra2.TabIndex = 10;
            lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(550, 88);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(54, 15);
            lblPalavra1.TabIndex = 9;
            lblPalavra1.Text = "Palavra 1";
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(462, 137);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(158, 23);
            txtPalavra2.TabIndex = 8;
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(615, 80);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(158, 23);
            txtPalavra1.TabIndex = 7;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInverse);
            Controls.Add(btnRemove1do2);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnInverse;
        private Button btnRemove1do2;
        private Label lblPalavra2;
        private Label lblPalavra1;
        private TextBox txtPalavra2;
        private TextBox txtPalavra1;
    }
}