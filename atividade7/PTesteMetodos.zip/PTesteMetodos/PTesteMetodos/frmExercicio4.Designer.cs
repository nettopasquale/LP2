﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnContaAlfabetico = new Button();
            btnBuscaBranco = new Button();
            btnContaNumerico = new Button();
            rchtxtFrase = new RichTextBox();
            SuspendLayout();
            // 
            // btnContaAlfabetico
            // 
            btnContaAlfabetico.Location = new Point(440, 592);
            btnContaAlfabetico.Margin = new Padding(4, 5, 4, 5);
            btnContaAlfabetico.Name = "btnContaAlfabetico";
            btnContaAlfabetico.Size = new Size(193, 85);
            btnContaAlfabetico.TabIndex = 9;
            btnContaAlfabetico.Text = "Conta Alfabetico";
            btnContaAlfabetico.UseVisualStyleBackColor = true;
            btnContaAlfabetico.Click += btnContaAlfabetico_Click;
            // 
            // btnBuscaBranco
            // 
            btnBuscaBranco.Location = new Point(441, 438);
            btnBuscaBranco.Margin = new Padding(4, 5, 4, 5);
            btnBuscaBranco.Name = "btnBuscaBranco";
            btnBuscaBranco.Size = new Size(191, 85);
            btnBuscaBranco.TabIndex = 8;
            btnBuscaBranco.Text = "Achar 1º caracter branco";
            btnBuscaBranco.UseVisualStyleBackColor = true;
            btnBuscaBranco.Click += btnBuscaBranco_Click;
            // 
            // btnContaNumerico
            // 
            btnContaNumerico.Location = new Point(436, 283);
            btnContaNumerico.Margin = new Padding(4, 5, 4, 5);
            btnContaNumerico.Name = "btnContaNumerico";
            btnContaNumerico.Size = new Size(197, 85);
            btnContaNumerico.TabIndex = 7;
            btnContaNumerico.Text = "Conta Caracter Numérico";
            btnContaNumerico.UseVisualStyleBackColor = true;
            btnContaNumerico.Click += btnContaNumerico_Click;
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(459, 78);
            rchtxtFrase.Margin = new Padding(4, 5, 4, 5);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(141, 157);
            rchtxtFrase.TabIndex = 10;
            rchtxtFrase.Text = "";
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1143, 750);
            Controls.Add(rchtxtFrase);
            Controls.Add(btnContaAlfabetico);
            Controls.Add(btnBuscaBranco);
            Controls.Add(btnContaNumerico);
            Margin = new Padding(4, 5, 4, 5);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
        }

        #endregion

        private Button btnContaAlfabetico;
        private Button btnBuscaBranco;
        private Button btnContaNumerico;
        private RichTextBox rchtxtFrase;
    }
}