﻿namespace PTesteMetodos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            menuStrip1 = new MenuStrip();
            exercício2ToolStripMenuItem = new ToolStripMenuItem();
            copiarToolStripMenuItem = new ToolStripMenuItem();
            colarToolStripMenuItem = new ToolStripMenuItem();
            exercício3ToolStripMenuItem = new ToolStripMenuItem();
            copiarToolStripMenuItem1 = new ToolStripMenuItem();
            colarToolStripMenuItem1 = new ToolStripMenuItem();
            exercícioToolStripMenuItem = new ToolStripMenuItem();
            copiarToolStripMenuItem2 = new ToolStripMenuItem();
            colarToolStripMenuItem2 = new ToolStripMenuItem();
            exercício5ToolStripMenuItem = new ToolStripMenuItem();
            copiarToolStripMenuItem3 = new ToolStripMenuItem();
            colarToolStripMenuItem3 = new ToolStripMenuItem();
            sairToolStripMenuItem = new ToolStripMenuItem();
            contextMenuStrip1 = new ContextMenuStrip(components);
            editorDeTextoToolStripMenuItem = new ToolStripMenuItem();
            calculadoraToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            contextMenuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { exercício2ToolStripMenuItem, exercício3ToolStripMenuItem, exercícioToolStripMenuItem, exercício5ToolStripMenuItem, sairToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // exercício2ToolStripMenuItem
            // 
            exercício2ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { copiarToolStripMenuItem, colarToolStripMenuItem });
            exercício2ToolStripMenuItem.Name = "exercício2ToolStripMenuItem";
            exercício2ToolStripMenuItem.Size = new Size(75, 20);
            exercício2ToolStripMenuItem.Text = "Exercício &2";
            exercício2ToolStripMenuItem.Click += exercício2ToolStripMenuItem_Click_1;
            // 
            // copiarToolStripMenuItem
            // 
            copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            copiarToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.C;
            copiarToolStripMenuItem.Size = new Size(180, 22);
            copiarToolStripMenuItem.Text = "Copiar";
            copiarToolStripMenuItem.Click += copiarToolStripMenuItem_Click;
            // 
            // colarToolStripMenuItem
            // 
            colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            colarToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.V;
            colarToolStripMenuItem.Size = new Size(180, 22);
            colarToolStripMenuItem.Text = "Colar";
            colarToolStripMenuItem.Click += colarToolStripMenuItem_Click;
            // 
            // exercício3ToolStripMenuItem
            // 
            exercício3ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { copiarToolStripMenuItem1, colarToolStripMenuItem1 });
            exercício3ToolStripMenuItem.Name = "exercício3ToolStripMenuItem";
            exercício3ToolStripMenuItem.Size = new Size(75, 20);
            exercício3ToolStripMenuItem.Text = "Exercício &3";
            exercício3ToolStripMenuItem.Click += exercício3ToolStripMenuItem_Click;
            // 
            // copiarToolStripMenuItem1
            // 
            copiarToolStripMenuItem1.Name = "copiarToolStripMenuItem1";
            copiarToolStripMenuItem1.Size = new Size(67, 22);
            // 
            // colarToolStripMenuItem1
            // 
            colarToolStripMenuItem1.Name = "colarToolStripMenuItem1";
            colarToolStripMenuItem1.Size = new Size(67, 22);
            // 
            // exercícioToolStripMenuItem
            // 
            exercícioToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { copiarToolStripMenuItem2, colarToolStripMenuItem2 });
            exercícioToolStripMenuItem.Name = "exercícioToolStripMenuItem";
            exercícioToolStripMenuItem.Size = new Size(75, 20);
            exercícioToolStripMenuItem.Text = "Exercício &4";
            exercícioToolStripMenuItem.Click += exercícioToolStripMenuItem_Click;
            // 
            // copiarToolStripMenuItem2
            // 
            copiarToolStripMenuItem2.Name = "copiarToolStripMenuItem2";
            copiarToolStripMenuItem2.Size = new Size(67, 22);
            // 
            // colarToolStripMenuItem2
            // 
            colarToolStripMenuItem2.Name = "colarToolStripMenuItem2";
            colarToolStripMenuItem2.Size = new Size(67, 22);
            // 
            // exercício5ToolStripMenuItem
            // 
            exercício5ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { copiarToolStripMenuItem3, colarToolStripMenuItem3 });
            exercício5ToolStripMenuItem.Name = "exercício5ToolStripMenuItem";
            exercício5ToolStripMenuItem.Size = new Size(75, 20);
            exercício5ToolStripMenuItem.Text = "Exercício &5";
            exercício5ToolStripMenuItem.Click += exercício5ToolStripMenuItem_Click;
            // 
            // copiarToolStripMenuItem3
            // 
            copiarToolStripMenuItem3.Name = "copiarToolStripMenuItem3";
            copiarToolStripMenuItem3.Size = new Size(67, 22);
            // 
            // colarToolStripMenuItem3
            // 
            colarToolStripMenuItem3.Name = "colarToolStripMenuItem3";
            colarToolStripMenuItem3.Size = new Size(67, 22);
            // 
            // sairToolStripMenuItem
            // 
            sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            sairToolStripMenuItem.Size = new Size(38, 20);
            sairToolStripMenuItem.Text = "&Sair";
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { editorDeTextoToolStripMenuItem, calculadoraToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(153, 48);
            // 
            // editorDeTextoToolStripMenuItem
            // 
            editorDeTextoToolStripMenuItem.Name = "editorDeTextoToolStripMenuItem";
            editorDeTextoToolStripMenuItem.Size = new Size(152, 22);
            editorDeTextoToolStripMenuItem.Text = "Editor de Texto";
            // 
            // calculadoraToolStripMenuItem
            // 
            calculadoraToolStripMenuItem.Name = "calculadoraToolStripMenuItem";
            calculadoraToolStripMenuItem.Size = new Size(152, 22);
            calculadoraToolStripMenuItem.Text = "Calculadora";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            ContextMenuStrip = contextMenuStrip1;
            Controls.Add(menuStrip1);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            contextMenuStrip1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem exercício2ToolStripMenuItem;
        private ToolStripMenuItem exercício3ToolStripMenuItem;
        private ToolStripMenuItem exercícioToolStripMenuItem;
        private ToolStripMenuItem copiarToolStripMenuItem;
        private ToolStripMenuItem colarToolStripMenuItem;
        private ToolStripMenuItem copiarToolStripMenuItem1;
        private ToolStripMenuItem colarToolStripMenuItem1;
        private ToolStripMenuItem copiarToolStripMenuItem2;
        private ToolStripMenuItem colarToolStripMenuItem2;
        private ToolStripMenuItem exercício5ToolStripMenuItem;
        private ToolStripMenuItem copiarToolStripMenuItem3;
        private ToolStripMenuItem colarToolStripMenuItem3;
        private ToolStripMenuItem sairToolStripMenuItem;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem editorDeTextoToolStripMenuItem;
        private ToolStripMenuItem calculadoraToolStripMenuItem;
    }
}
