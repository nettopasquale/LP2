﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemove1do2_Click(object sender, EventArgs e)
        {
            txtPalavra1.Text = txtPalavra2.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void btnInverse_Click(object sender, EventArgs e)
        {
            char[] vetor = txtPalavra1.Text.ToCharArray();
            Array.Reverse(vetor); //inverte
            txtPalavra2.Text = new string(vetor); //cria uma string com parametros de vetor
        }
    }
}
