﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNumerico_Click(object sender, EventArgs e)
        {
            int cont, qtdNumeros;

            cont = 0;
            qtdNumeros = 0;
            while (cont < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text, cont))
                    qtdNumeros++;

                cont++;
            }
            MessageBox.Show($"Temos ao todo {qtdNumeros} números");
        }

        private void btnBuscaBranco_Click(object sender, EventArgs e)
        {
            char init;
            int cont = 0, index = 0;

            for (cont = 0; cont < rchtxtFrase.Text.Length; cont++)
            {

                if (char.IsWhiteSpace(rchtxtFrase.Text[cont]))
                {
                    index = cont;
                    break;
                }
            }

            MessageBox.Show($"O espaço em branco está na posição {index}.");

        }

        private void btnContaAlfabetico_Click(object sender, EventArgs e)
        {
            int qtdAlfaNumericos;

            qtdAlfaNumericos = 0;

            foreach(char alfinha in rchtxtFrase.Text)
            {
                if (char.IsLetter(alfinha))
                    qtdAlfaNumericos++;
            }

            MessageBox.Show($"Temos ao todo {qtdAlfaNumericos} caracteres Alfa Numéricos");

        }
    }
}
