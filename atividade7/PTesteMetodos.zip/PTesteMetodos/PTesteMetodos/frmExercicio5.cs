﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        double numb1, numb2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out numb1))
            {
                MessageBox.Show("Valores incorretos!");
                txtNumero1.Focus();
            }

        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out numb2))
            {
                MessageBox.Show("Valores incorretos!");
                txtNumero2.Focus();
            }

        }
        private void btnRandom_Click(object sender, EventArgs e)
        {

            Random random = new Random();

            if (numb2 > numb1)
            {
                double sorteio = random.NextDouble() * (numb2 - numb1);

                MessageBox.Show($"O número sorteado é {Math.Round(sorteio)}");
            }
            else
            {
                MessageBox.Show("Sorteio Não é possível, favor informar um número maior para Número 2.");
                txtNumero2.Focus();
            }
        }
    }
}
