﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PDisaster0030482321003
{
    public partial class FormCidade : Form
    {
        private BindingSource bnCidade = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsCidade = new DataSet();
        public FormCidade()
        {
            InitializeComponent();
        }

        private void tbDados_Click(object sender, EventArgs e)
        {

        }

        private void FormCidade_Load(object sender, EventArgs e)
        {
            try
            {
                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                bnCidade.DataSource = dsCidade.Tables["Cidade"];
                dgvCidade.DataSource = bnCidade;
                bnvCidade.BindingSource = bnCidade;

                txtIdCidade.DataBindings.Add("TEXT", bnCidade, "idCidade");
                txtNome.DataBindings.Add("TEXT", bnCidade, "nome");
                cbxUF.DataBindings.Add("SelectedItem", bnCidade, "uf");
                mskbxPopulacao.DataBindings.Add("TEXT", bnCidade, "populacao");
                mskbxPopulacao.Enabled = false; 
                cbxUF.Enabled = false; 
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbCidade.SelectedIndex == 0)
            {
                tbCidade.SelectTab(1);
            }
            bnCidade.AddNew();

            txtNome.Enabled = true;
            cbxUF.Enabled = true;
            cbxUF.SelectedIndex = 0;
            mskbxPopulacao.Enabled = true;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbCidade.SelectedIndex == 0)
            {
                tbCidade.SelectTab(1);
            }

            txtNome.Enabled = true;
            cbxUF.Enabled = true;
            mskbxPopulacao.Enabled = true;

            txtNome.Focus();

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            int auxiliar = 0;

            //validar dados

            if(txtNome.Text == "")
            {
                MessageBox.Show("Cidade Inválida!");
            }

            else if (!int.TryParse(mskbxPopulacao.Text, out auxiliar) || auxiliar <= 0)
            {
                MessageBox.Show("População Inválida!");
            }
            else
            {
                Cidade RegCid = new Cidade();

                RegCid.Nome = txtNome.Text;
                RegCid.Uf = cbxUF.SelectedItem.ToString();
                RegCid.Populacao = Convert.ToInt32(mskbxPopulacao.Text);

                if(bInclusao)
                {
                    if(RegCid.Incluir() >0)
                    {
                        MessageBox.Show("Cidade adiciona com sucesso");

                        txtIdCidade.Enabled = false;
                        txtNome.Enabled = false;
                        cbxUF.Enabled = false;
                        mskbxPopulacao.Enabled = false;

                        txtNome.Focus();

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        dsCidade.Tables.Clear();
                        dsCidade.Tables.Add(RegCid.Listar());
                        bnCidade.DataSource = dsCidade.Tables["Cidade"];

                        bInclusao = false;
                    }
                    else 
                    {
                        MessageBox.Show("Erro ao gravar cidade"); 
                    }
                }
                else
                {
                    RegCid.IdCidade = Convert.ToInt32(txtIdCidade.Text);
                    if (RegCid.Alterar() > 0)
                    {
                        MessageBox.Show("Cidade alterada Com sucesso");

                        txtIdCidade.Enabled = false;
                        txtNome.Enabled = false;
                        cbxUF.Enabled = false;
                        mskbxPopulacao.Enabled = false;

                        txtNome.Focus();

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        dsCidade.Tables.Clear();
                        dsCidade.Tables.Add(RegCid.Listar());
                        bnCidade.DataSource = dsCidade.Tables["Cidade"];
                    }
                    else
                {
                    MessageBox.Show("Erro ao alterar cidade");
                }
            }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbCidade.SelectedIndex == 0)
            {
                tbCidade.SelectTab(1);
            }

            if (MessageBox.Show("Confirmar a exclusão", " Sim ou Não", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)

            {
                Cidade RegCid = new Cidade();

                RegCid.IdCidade = Convert.ToInt16(txtIdCidade.Text);

                if (RegCid.Excluir() > 0)

                {
                    MessageBox.Show("Cidade excluído com sucesso");
                    Cidade R = new Cidade();
                    dsCidade.Tables.Clear();
                    dsCidade.Tables.Add(R.Listar());
                    bnCidade.DataSource = dsCidade.Tables["Cidade"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Cidade!");
                }

            }
        }
            private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnCidade.CancelEdit();

            txtNome.Enabled = false;
            cbxUF.Enabled = false;
            mskbxPopulacao.Enabled = false;
            txtIdCidade.Enabled = false;
            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {

            Close();
        }
    }

    }
