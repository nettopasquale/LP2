﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio3 : Form
    {
        string palindromo;
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnEhPalindromo_Click(object sender, EventArgs e)
        {
            string aux;
            int tamanho, cont;

            palindromo = txtPalindromo.Text;

            aux = palindromo.ToLower().Replace(" ", "");

            tamanho = aux.Length;

            cont = 0;

            for(int i = 0; i < tamanho / 2; i++)
            {
                if (aux[i] == aux[tamanho - 1 - i])
                {
                    cont++;
                }
            }

            _ = cont == tamanho / 2 ? MessageBox.Show("É palíndromo!") : MessageBox.Show("Não é palíndromo!");


        }
    }
}
