﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio2 : Form
    {
        int numN;
        public frmExercicio2()
        {
            InitializeComponent();
        }
        private void btnNumeroH_Validated(object sender, EventArgs e)
        {
            if(!Int32.TryParse(txtNumeroN.Text, out numN))
            {
                MessageBox.Show("Por favor digite um número!");
                txtNumeroN.Focus();
            }

        }

        private void btnNumeroH_Click(object sender, EventArgs e)
        {
            numN = Convert.ToInt32(txtNumeroN.Text);
            double numH = 0;

            if(numN == 0)
            {
                MessageBox.Show("Por favor informe um número maior que 0!");
            }
            else
            {
                for(int i = 1; i <= numN; i++)
                {
                    numH += Math.Pow(i, -1) ;
                    Console.Write($"SomaN: {numH}");
                }

                MessageBox.Show($"Número H é: {numH.ToString("N2")}");
            }

        }

    }
}
