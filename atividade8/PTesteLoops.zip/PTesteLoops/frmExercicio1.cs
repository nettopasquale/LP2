﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnContWhiteSpace_Click(object sender, EventArgs e)
        {
            int whiteSpace = 0;

            foreach(char x in rchtxtFrase.Text)
            {
                if (char.IsWhiteSpace(x))
                {
                    whiteSpace++;
                }
            }

            MessageBox.Show($"O número de espaços em branco é de {whiteSpace}");
        }
        private void btnContR_Click(object sender, EventArgs e)
        {
            int contR = 0, cont = 0;

            while(cont < rchtxtFrase.Text.Length)
            {
                if (rchtxtFrase.Text[cont] == 'R')
                    contR++;

                cont++;
            }
            MessageBox.Show($"O número de R's na frase é de {contR}.");
        }

        private void btnContDoubleChar_Click(object sender, EventArgs e)
        {
            int cont, duploChar = 0;

            for(cont = 1; cont < rchtxtFrase.TextLength; cont++)
            {
                if (rchtxtFrase.Text[cont] == rchtxtFrase.Text[cont - 1])
                    duploChar++;
            }
            MessageBox.Show($"O número de pares de letras na frase é de {duploChar}");

        }

    }
}
