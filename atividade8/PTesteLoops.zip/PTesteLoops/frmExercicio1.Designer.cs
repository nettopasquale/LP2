﻿namespace PTesteLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContWhiteSpace = new System.Windows.Forms.Button();
            this.btnContR = new System.Windows.Forms.Button();
            this.btnContDoubleChar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(365, 128);
            this.rchtxtFrase.MaxLength = 100;
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(500, 88);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContWhiteSpace
            // 
            this.btnContWhiteSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContWhiteSpace.Location = new System.Drawing.Point(526, 257);
            this.btnContWhiteSpace.Name = "btnContWhiteSpace";
            this.btnContWhiteSpace.Size = new System.Drawing.Size(178, 102);
            this.btnContWhiteSpace.TabIndex = 1;
            this.btnContWhiteSpace.Text = "Contar Espaço em Branco";
            this.btnContWhiteSpace.UseVisualStyleBackColor = true;
            this.btnContWhiteSpace.Click += new System.EventHandler(this.btnContWhiteSpace_Click);
            // 
            // btnContR
            // 
            this.btnContR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContR.Location = new System.Drawing.Point(526, 397);
            this.btnContR.Name = "btnContR";
            this.btnContR.Size = new System.Drawing.Size(178, 102);
            this.btnContR.TabIndex = 2;
            this.btnContR.Text = "Contar R\'s";
            this.btnContR.UseVisualStyleBackColor = true;
            this.btnContR.Click += new System.EventHandler(this.btnContR_Click);
            // 
            // btnContDoubleChar
            // 
            this.btnContDoubleChar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContDoubleChar.Location = new System.Drawing.Point(526, 550);
            this.btnContDoubleChar.Name = "btnContDoubleChar";
            this.btnContDoubleChar.Size = new System.Drawing.Size(178, 102);
            this.btnContDoubleChar.TabIndex = 3;
            this.btnContDoubleChar.Text = "Contar par de letras";
            this.btnContDoubleChar.UseVisualStyleBackColor = true;
            this.btnContDoubleChar.Click += new System.EventHandler(this.btnContDoubleChar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(362, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(507, 37);
            this.label1.TabIndex = 4;
            this.label1.Text = "Escreva seu texto aqui em baixo";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1323, 751);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnContDoubleChar);
            this.Controls.Add(this.btnContR);
            this.Controls.Add(this.btnContWhiteSpace);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContWhiteSpace;
        private System.Windows.Forms.Button btnContR;
        private System.Windows.Forms.Button btnContDoubleChar;
        private System.Windows.Forms.Label label1;
    }
}