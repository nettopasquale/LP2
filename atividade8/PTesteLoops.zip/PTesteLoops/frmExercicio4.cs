﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio4 : Form
    {
        double salarioCargo, gratificacao;
        int producao, matricula;
        string nome;

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcSalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(msktxtSalario.Text, out salarioCargo))
            {
                MessageBox.Show("Formato do salário incorreto!");
                msktxtSalario.Focus();
            }

            if (!Int32.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Formato de produção incorreto!");
                txtProducao.Focus();

            }

            if (!double.TryParse(msktxtGratificacao.Text, out gratificacao))
            {
                MessageBox.Show("Formato de gratificação incorreto!");
                msktxtGratificacao.Focus();
            }

            if (nome.Length == 0)
            {
                MessageBox.Show("Informe seu nome!");
                txtNome.Focus();
            }

            if (matricula == 0)
            {
                MessageBox.Show("Informe sua matrícula!");
            }

        }

        private void btnCalcSalBruto_Click(object sender, EventArgs e)
        {

            double salarioBruto;

            nome = txtNome.Text;
            matricula = Convert.ToInt32(txtMatricula.Text);
            producao = Convert.ToInt32(txtProducao.Text);
            salarioCargo = Convert.ToDouble(msktxtSalario.Text);
            gratificacao = Convert.ToDouble(msktxtGratificacao.Text);
            
            if(producao >= 150)
                salarioBruto = salarioCargo + salarioCargo * (.25) + gratificacao;

            else if(producao > 119)
                salarioBruto = salarioCargo + salarioCargo * (.15 ) + gratificacao;

            else if(producao > 99)
                salarioBruto = salarioCargo + (salarioCargo * .05) + gratificacao;

            else
                salarioBruto = salarioCargo + (salarioCargo * 0) + gratificacao;


            if (salarioBruto > 7000 && producao >= 150 && gratificacao > 0)
            {
                salarioBruto = salarioCargo + salarioCargo * (.05 + 0.1 + 0.1) + gratificacao;
            }
            else if (salarioBruto > 7000)
            {
                salarioBruto = 7000;

            }

            MessageBox.Show($"Prezado(a) {nome} da Matricula: {matricula}, " +
                $"Seu salário bruto é de R${Math.Round(salarioBruto, 2)}");
        
        }

    }
}
