﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatriz
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void btnGabarito_Click(object sender, EventArgs e)
        {
            string ra = txtRA.Text;
            string[] gabarito = ["A", "D", "B", "E", "C", "A", "E", "D", "B", "B"];
            int qtdAlunos;

            if (!int.TryParse(ra, out qtdAlunos))
            {
                MessageBox.Show("Insira um número válido de RA!");
                ra = "";
                txtRA.Text = ra;
            }
            else
            {
                if(qtdAlunos == 0)
                {
                    qtdAlunos = 2;
                }
                else
                {
                    qtdAlunos = qtdAlunos + 1;

                }
            }

            string[] acertosAluno = new string[qtdAlunos];
            string[,] alunoResposta = new string[qtdAlunos, 10];

            for (int i = 0; i < alunoResposta.GetLength(0); i++)
            {
                acertosAluno[i] = $"O aluno {i + 1} acertou as seguintes questões: ";
                for (int j = 0; j < alunoResposta.GetLength(1); j++) 
                {
                    alunoResposta[i, j] = Interaction.InputBox($"Digite a resposta {j + 1} do {i + 1}º aluno", "Entrada de dados").ToUpper();

                    if (!(alunoResposta[i, j] == "A"
                        || alunoResposta[i, j] == "B" 
                        || alunoResposta[i, j] == "C"
                        || alunoResposta[i, j] == "D"
                        || alunoResposta[i, j] == "E"))
                    {
                        MessageBox.Show("Resposta inválida, digite uma resposta válida!");
                        j--;
                    }
                
                }

            }
            for(int i = 0; i < qtdAlunos; i++)
            {
                for (int j = 0; j < gabarito.Length; j++)
                {
                    if (alunoResposta[i, j] == gabarito[j])
                    {
                        acertosAluno[i] += $"[Exercício{j +i}]";
                    }
                }

            }

            lstbNomes.Items.AddRange(acertosAluno);
        }
    }
} 
