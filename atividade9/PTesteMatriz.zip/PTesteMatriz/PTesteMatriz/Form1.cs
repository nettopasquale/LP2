using Microsoft.VisualBasic;
using System.Collections;
using System.Runtime.Intrinsics.X86;

namespace PTesteMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetorNum = new int[20];
            string aux;

            for (int i = 0; i < vetorNum.Length; i++)
            {
                aux = Interaction.InputBox($"Digite um n�mero {i + 1}�",
                    "Entrada de Dados");

                if (!int.TryParse(aux, out vetorNum[i]))
                {
                    MessageBox.Show("N�mero inv�lido!");
                    i--;
                }
            }

            Array.Reverse(vetorNum); // inverte o vetor

            aux = "";

            foreach (int j in vetorNum)
            {
                aux += j + "\n";
            }

            MessageBox.Show(aux);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            string aux;
            ArrayList vetorLista = new ArrayList() { "Ana", "Andr�", "D�bora", "F�tima", "Jo�o", "Janete", "Ot�vio", "Marcelo", "Pedro", "Thais" };

            vetorLista.RemoveAt(6);

            aux = "";

            foreach (string nome in vetorLista)
            {

                aux += nome + "\n";
            }

            MessageBox.Show(aux);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notasAlunos = new double[20, 3];
            double[] mediaFinal = new double[20];
            int cont;
            string aux = "";


            for (int i = 0; i < notasAlunos.GetLength(0); i++)
            {
                mediaFinal[i] = 0;

                for (int j = 0; j < notasAlunos.GetLength(1); j++)
                {

                    if ((!double.TryParse(Interaction.InputBox($"Insira a {i + 1}� Nota", "Entrada de valores"), out notasAlunos[i,j])))
                    {
                        MessageBox.Show("Nota Inv�lida!");
                        j--;
                    }
                    else
                    {
                        mediaFinal[i] += notasAlunos[i, j];
                    }
                }
                for(cont = 0; cont < notasAlunos.GetLength(0); cont++)
                {
                    aux += $"Aluno {i + 1}: M�dia: " + mediaFinal[cont] / 3 + "\n";

                }
                    
                MessageBox.Show(aux);

            }

        }

        private void btnEx4_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<RA_Notas>().Count() > 0)
            {
                Application.OpenForms["RA_Notas"]?.BringToFront();
            }

            else
            {
                RA_Notas obj1 = new RA_Notas();
                obj1.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"]?.BringToFront();
            }

            else
            {
                FrmExercicio5 obj2 = new FrmExercicio5();
                obj2.Show();

            }
        }
    }
}
