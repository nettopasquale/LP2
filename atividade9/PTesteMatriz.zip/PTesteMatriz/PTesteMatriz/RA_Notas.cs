﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PTesteMatriz
{
    public partial class RA_Notas : Form
    {
        public RA_Notas()
        {
            InitializeComponent();
        }

        private void btnListaNomes_Click(object sender, EventArgs e)
        {
            
            string ra = txtRA.Text;
            int qtdPessoas;

            if(!int.TryParse(ra, out qtdPessoas))
            {
                MessageBox.Show("Insira um número válido de RA!");
                ra = "";
                txtRA.Text = ra;
            }
            else
            {
                if (qtdPessoas == 0)
                {
                    qtdPessoas = 10;

                }
                else if (qtdPessoas == 1)
                {
                    qtdPessoas = 2;
                }


                string[] listaPessoas = new string[qtdPessoas];
                string[] auxiliar = new string[qtdPessoas];

                for(int i = 0; i < qtdPessoas; i++)
                {
                    listaPessoas[i] = Interaction.InputBox($"Digite o nome da {i + 1}ª pessoa", "Entrada de dados");

                    auxiliar[i] = listaPessoas[i].Replace(" ", "");

                    listaPessoas[i] = $"O nome: {listaPessoas[i]} tem {auxiliar[i].Length.ToString()} caracteres";
                }

                lstbNomes.Items.AddRange(listaPessoas);
            }

        }
    }
}
