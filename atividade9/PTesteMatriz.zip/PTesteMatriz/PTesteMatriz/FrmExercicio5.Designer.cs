﻿namespace PTesteMatriz
{
    partial class FrmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblRA = new Label();
            txtRA = new TextBox();
            lstbNomes = new ListBox();
            btnGabarito = new Button();
            SuspendLayout();
            // 
            // lblRA
            // 
            lblRA.AutoSize = true;
            lblRA.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRA.Location = new Point(60, 111);
            lblRA.Name = "lblRA";
            lblRA.Size = new Size(333, 30);
            lblRA.TabIndex = 9;
            lblRA.Text = "Digite Seu Último Dígito do RA";
            // 
            // txtRA
            // 
            txtRA.Location = new Point(74, 170);
            txtRA.Name = "txtRA";
            txtRA.Size = new Size(280, 31);
            txtRA.TabIndex = 8;
            // 
            // lstbNomes
            // 
            lstbNomes.FormattingEnabled = true;
            lstbNomes.ItemHeight = 25;
            lstbNomes.Location = new Point(681, 148);
            lstbNomes.Name = "lstbNomes";
            lstbNomes.Size = new Size(462, 754);
            lstbNomes.TabIndex = 7;
            // 
            // btnGabarito
            // 
            btnGabarito.Location = new Point(74, 257);
            btnGabarito.Name = "btnGabarito";
            btnGabarito.Size = new Size(280, 174);
            btnGabarito.TabIndex = 6;
            btnGabarito.Text = "Gabarito";
            btnGabarito.UseVisualStyleBackColor = true;
            btnGabarito.Click += btnGabarito_Click;
            // 
            // FrmExercicio5
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1202, 1012);
            Controls.Add(lblRA);
            Controls.Add(txtRA);
            Controls.Add(lstbNomes);
            Controls.Add(btnGabarito);
            Name = "FrmExercicio5";
            Text = "FrmExercicio5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRA;
        private TextBox txtRA;
        private ListBox lstbNomes;
        private Button btnGabarito;
    }
}