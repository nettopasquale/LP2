﻿namespace PTesteMatriz
{
    partial class RA_Notas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnListaNomes = new Button();
            lstbNomes = new ListBox();
            imageList1 = new ImageList(components);
            txtRA = new TextBox();
            lblRA = new Label();
            SuspendLayout();
            // 
            // btnListaNomes
            // 
            btnListaNomes.Location = new Point(417, 242);
            btnListaNomes.Name = "btnListaNomes";
            btnListaNomes.Size = new Size(280, 174);
            btnListaNomes.TabIndex = 0;
            btnListaNomes.Text = "Listar Nomes";
            btnListaNomes.UseVisualStyleBackColor = true;
            btnListaNomes.Click += btnListaNomes_Click;
            // 
            // lstbNomes
            // 
            lstbNomes.FormattingEnabled = true;
            lstbNomes.ItemHeight = 25;
            lstbNomes.Location = new Point(1024, 88);
            lstbNomes.Name = "lstbNomes";
            lstbNomes.Size = new Size(462, 754);
            lstbNomes.TabIndex = 2;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth32Bit;
            imageList1.ImageSize = new Size(16, 16);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // txtRA
            // 
            txtRA.Location = new Point(417, 110);
            txtRA.Name = "txtRA";
            txtRA.Size = new Size(280, 31);
            txtRA.TabIndex = 3;
            // 
            // lblRA
            // 
            lblRA.AutoSize = true;
            lblRA.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRA.Location = new Point(403, 51);
            lblRA.Name = "lblRA";
            lblRA.Size = new Size(333, 30);
            lblRA.TabIndex = 4;
            lblRA.Text = "Digite Seu Último Dígito do RA";
            // 
            // RA_Notas
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1570, 1088);
            Controls.Add(lblRA);
            Controls.Add(txtRA);
            Controls.Add(lstbNomes);
            Controls.Add(btnListaNomes);
            Name = "RA_Notas";
            Text = "RA_Notas";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnListaNomes;
        private ListBox lstbNomes;
        private ImageList imageList1;
        private TextBox txtRA;
        private Label lblRA;
    }
}