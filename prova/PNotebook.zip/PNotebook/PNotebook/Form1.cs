using Microsoft.VisualBasic;

namespace PNotebook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int RA = 3;

            double[,] notebookValores = new double[RA, 3];
            double[] mediaValores = new double[RA];
            double mediaFinal = 0;
            string aux = "", aux2 = "";

            for (int i = 0; i < notebookValores.GetLength(0); i++)
            {
                mediaValores[i] = 0;
                for (int j = 0; j < 3; j++)
                {
                    if (!double.TryParse(Interaction.InputBox($"Digite o valor do {i + 1}� Notebook para a {j + 1}� loja: ", "Entrada de valores"), out notebookValores[i, j]))
                    {
                        MessageBox.Show("Entrada inv�lida! Digite Um Valor correto!");
                        i--;
                    }
                    else
                    {
                        mediaValores[i] += notebookValores[i, j];
                        aux = $"Notebook {i + 1} Loja{j + 1}: R${notebookValores[i, j].ToString("N2")}";
                    }

                }
                mediaValores[i] = mediaValores[i] / 3;
                
            }

            for (int i = 0; i < mediaValores.Length; i++)
            {
                mediaFinal += mediaValores[i];

                aux2 = $"M�dia: {mediaFinal}";
            }
                mediaFinal = mediaFinal / 3;

            lstbNotebooks.Items.AddRange(aux + aux2);

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbNotebooks.Text = String.Empty;
        }
    }
}
