﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblLadoA = new Label();
            mskbxA = new MaskedTextBox();
            mskbxB = new MaskedTextBox();
            lblLadoB = new Label();
            mskbxC = new MaskedTextBox();
            lblLadoC = new Label();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblLadoA
            // 
            lblLadoA.AutoSize = true;
            lblLadoA.Location = new Point(273, 49);
            lblLadoA.Name = "lblLadoA";
            lblLadoA.Size = new Size(44, 15);
            lblLadoA.TabIndex = 0;
            lblLadoA.Text = "Lado A";
            lblLadoA.Click += label1_Click;
            // 
            // mskbxA
            // 
            mskbxA.Location = new Point(342, 41);
            mskbxA.Mask = "00,00";
            mskbxA.Name = "mskbxA";
            mskbxA.Size = new Size(100, 23);
            mskbxA.TabIndex = 1;
            mskbxA.Validated += mskbxA_Validated;
            // 
            // mskbxB
            // 
            mskbxB.Location = new Point(524, 183);
            mskbxB.Mask = "00,00";
            mskbxB.Name = "mskbxB";
            mskbxB.Size = new Size(100, 23);
            mskbxB.TabIndex = 3;
            mskbxB.Validated += mskbxB_Validated;
            // 
            // lblLadoB
            // 
            lblLadoB.AutoSize = true;
            lblLadoB.Location = new Point(455, 191);
            lblLadoB.Name = "lblLadoB";
            lblLadoB.Size = new Size(43, 15);
            lblLadoB.TabIndex = 2;
            lblLadoB.Text = "Lado B";
            // 
            // mskbxC
            // 
            mskbxC.Location = new Point(185, 183);
            mskbxC.Mask = "00,00";
            mskbxC.Name = "mskbxC";
            mskbxC.Size = new Size(100, 23);
            mskbxC.TabIndex = 5;
            mskbxC.Validated += mskbxC_Validated;
            // 
            // lblLadoC
            // 
            lblLadoC.AutoSize = true;
            lblLadoC.Location = new Point(116, 191);
            lblLadoC.Name = "lblLadoC";
            lblLadoC.Size = new Size(44, 15);
            lblLadoC.TabIndex = 4;
            lblLadoC.Text = "Lado C";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(182, 294);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(103, 47);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(342, 294);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(106, 47);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(518, 294);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(106, 47);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1169, 450);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(mskbxC);
            Controls.Add(lblLadoC);
            Controls.Add(mskbxB);
            Controls.Add(lblLadoB);
            Controls.Add(mskbxA);
            Controls.Add(lblLadoA);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLadoA;
        private MaskedTextBox mskbxA;
        private MaskedTextBox mskbxB;
        private Label lblLadoB;
        private MaskedTextBox mskbxC;
        private Label lblLadoC;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
    }
}
