namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void mskbxA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxA.Text, out ladoA))
            {
                MessageBox.Show("Valor do lado A errado! Informe um correto.");
                mskbxA.Focus();
            }
        }

        private void mskbxB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxB.Text, out ladoB))
            {
                MessageBox.Show("Valor do lado B errado! Informe um correto.");
                mskbxB.Focus();
            }
        }

        private void mskbxC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxC.Text, out ladoC))
            {
                MessageBox.Show("Valor do lado C errado! Informe um correto.");
                mskbxC.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxA.Text = String.Empty;
            mskbxB.Text = String.Empty;
            mskbxC.Text = String.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (ladoA > (Math.Abs(ladoB - ladoC)) && ladoA < (ladoB + ladoC)
                && ladoB > (Math.Abs(ladoA - ladoC)) && ladoB < (ladoA + ladoC)
                && ladoC > (Math.Abs(ladoA - ladoB)) && ladoC < (ladoA + ladoB))
            {

                if (ladoA == ladoB && ladoA == ladoC && ladoB == ladoC)
                    MessageBox.Show("O triangulo � equil�tero!");
                else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                    MessageBox.Show("O triangulo � is�sceles!");
                else if (ladoA != ladoB && ladoA != ladoC && ladoB != ladoC)
                    MessageBox.Show("O triangulo � escaleno!");
            } else
                MessageBox.Show("Os dados informados n�o formam um tri�ngulo. Tente Novamente!");
        }
    }
}
